import Menu from "../menu/menu";

const Third= (props)=>{
    return(
     <div>
        <Menu/>

        <h2>
            This is my Third component;
        </h2>

        First Name : <b> {props.firstName} </b>
        <br/>
        Last Name : <b> {props.lastName} </b>
        <br/>
        Company : <b> {props.company}</b>

     </div>   
    )

}
export default Third;