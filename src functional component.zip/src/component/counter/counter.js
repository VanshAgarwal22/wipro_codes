import { useState } from "react"
import Menu from "../menu/menu";

const Counter = () =>{
    const [count ,setCount] =useState(0)
    // const increment =()=>{
    //     setCount(count+1)
    // }
    // const decrement =()=>{
    //     setCount(count-1)
    // }
    return(
        <div>
            <Menu/>
            Count is : <b>{count}</b><br/>
            <input type="button " value="Increment" onClick={()=>setCount(count+1)} />
            <input type="button " value="Decrement" onClick={()=>setCount(count-1)} />
        </div>
    )
}
export default Counter;