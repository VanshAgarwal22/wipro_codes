import Menu from "../menu/menu";


const Second = ()=>{
    return(
     <div>
        <Menu/>
        <h2>
            This is my second component;
        </h2>
     </div>   
    )

}
export default Second;