import Menu from "../menu/menu";


const First =  () =>{
    return(
        <div>
            <Menu/>
            <h1>Welcome!</h1>
            <p>This is a functional component</p>

        </div>
            
        
    )
}
export default First;