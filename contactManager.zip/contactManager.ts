// Define the Contact interface
interface Contact {
  id: number;
  name: string;
  email: string;
  phone: string;
}

// Create the ContactManager class
class ContactManager {
  private contacts: Contact[] = [];

  // Method to add a new contact
  addContact(contact: Contact): void {
    this.contacts.push(contact);
    console.log("Contact successfully added.");
  }

  // Method to view all contacts
  viewContacts(): Contact[] {
    return this.contacts;
  }

  // Method to modify an existing contact by id
  modifyContact(id: number, updatedContact: Partial<Contact>): void {
    const contact = this.contacts.find(c => c.id === id);
    if (!contact) {
      console.log("Error: Contact not found.");
      return;
    }

    // Update the contact with provided values
    Object.assign(contact, updatedContact);
    console.log("Contact successfully updated.");
  }

  // Method to delete a contact by id
  deleteContact(id: number): void {
    const contactIndex = this.contacts.findIndex(c => c.id === id);
    if (contactIndex === -1) {
      console.log("Error: Contact not found.");
      return;
    }

    // Remove the contact from the array
    this.contacts.splice(contactIndex, 1);
    console.log("Contact successfully deleted.");
  }
}

// Create a new instance of ContactManager
const manager = new ContactManager();

// Test: Add contacts
manager.addContact({ id: 1, name: "John Doe", email: "john@example.com", phone: "123-456-7890" });
manager.addContact({ id: 2, name: "Jane Smith", email: "jane@example.com", phone: "987-654-3210" });

// Test: View contacts
console.log(manager.viewContacts());

// Test: Modify a contact
manager.modifyContact(1, { email: "john.doe@newdomain.com", phone: "111-222-3333" });
console.log(manager.viewContacts());

// Test: Attempt to modify a non-existent contact
manager.modifyContact(3, { name: "Not Found" });

// Test: Delete a contact
manager.deleteContact(2);
console.log(manager.viewContacts());

// Test: Attempt to delete a non-existent contact
manager.deleteContact(3);
