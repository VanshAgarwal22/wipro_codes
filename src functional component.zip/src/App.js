import logo from './logo.svg';
import './App.css';
import First from './component/first/first';
import Second from './component/second/second';
import Third from './component/third/third';
import Button from './component/button/button';
import Four from './component/four/four';
import Five from './component/five/five';
import Counter from './component/counter/counter';
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom';
import Menu from './component/menu/menu';

function App() {
  return (
    <div className="App">
      Hello guys!
      <br/>
      <BrowserRouter>
      <Routes>
      <Route path="/" element={<Menu />} />
      <Route path="/first" element={<First />} />
        <Route path="/second" element={<Second />} />
        <Route path="/third" element={<Third firstName="Vansh" lastName="Agarwal" company="Wipro" />} />
        <Route path="/four" element={<Four />} />
        <Route path="/five" element={<Five/>} />
        <Route path="/counter" element={<Counter />} />
        <Route path="/button" element={<Button/>} />

      </Routes>
      </BrowserRouter> 
     {/* <First/> <br/>
     <Second/>
     <Third firstName= "Vansh" lastName ="Agarwal" company ="Wipro"/>
     <Button/><br/>
     <Four/><br/>
     <Five/> <br/>
     <Counter/> */}
    </div>
  );
}

export default App;
