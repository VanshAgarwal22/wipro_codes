import Menu from "../menu/menu";

const Button = () =>{

    const vansh =()=>{
        alert("Hi i am vansh...");

    }
    const Abhishek = () => {
        alert("Hi I am Abhishek...");
    }
    const Muskan = () => {
        alert("Hi I am Muskan...")
    }
    return(
        
        <div>
            <Menu/>
            <input type="button" value="Vansh" onClick={vansh} /> 
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <input type="button" value="Abhiskek" onClick={Abhishek} />
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <input type="button" value="Muskan" onClick={Muskan} />
        </div>
    )
}
export default Button;